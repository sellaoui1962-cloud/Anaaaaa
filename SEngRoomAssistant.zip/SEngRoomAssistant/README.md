# S/ENG Room Network Assistant (MVP — المراحل 1 إلى 4)

تطبيق Android أصلي (Kotlin + Compose + Room) لتشخيص جودة الشبكة لغرف Yalla Ludo.
قياسات حقيقية فقط، بلا VPN وبلا Root وبلا Accessibility وبلا Shizuku في هذه النسخة.

## البناء (على جهازك)
1. ثبّت Android Studio (Koala أو أحدث) مع JDK 17.
2. File ▸ Open ▸ اختر مجلد المشروع، وانتظر Gradle Sync (يحتاج إنترنت أول مرة؛ سينشئ gradle wrapper تلقائياً).
3. وصّل OPPO CPH2159 (USB debugging) ثم Run ▸ app، أو: Build ▸ Build APK(s).
   الناتج: app/build/outputs/apk/debug/app-debug.apk
4. اختبارات الوحدات: ./gradlew test

## ما تم تنفيذه
- START/STOP: مراقبة خفيفة (اتصال TCP صغير كل 2 ثانية) تعرض Ping median/p95، Jitter، Loss، جودة الشبكة.
- Test Now: خط أساس (20 جولة × 3 وجهات) + DNS عبر UDP مباشر لثلاثة مزودين + تنزيل/رفع مؤقتان (حد 4 ثوانٍ و~4.5MB) مع قياس latency-under-load وBufferbloat.
- Wi‑Fi: RSSI، سرعة الربط، النطاق، القناة.
- مقارنة قبل/بعد: تحسن / لا فرق / تدهور مع الأرقام الخام، وتصدير JSON.
- حفظ محلي (Room) بلا IP عام ولا SSID.
- ملف Yalla Ludo: اختيار التطبيق المثبت (بلا package ثابت) + فتحه. لا عزل لحركته دون VPN.
- اختبارات يدوية: تأخير صوت المقدم (تقدير)، إرسال الشات، استقبال الشات.

## حدود مهمة
- RTT = زمن TCP connect (التطبيقات لا تملك ICMP). الأرقام قريبة من ping لكنها ليست مطابقة له.
- نقاط الاختبار: 1.1.1.1 / 8.8.8.8 / 9.9.9.9 (منفذ 443) وspeed.cloudflare.com للتحميل. ليست خوادم Yalla.
- رقم الرفع تقدير (بايتات سُلّمت للمقبس خلال المدة).
- لم يُبنَ هذا الكود في بيئة فيها Android SDK؛ إن ظهر خطأ ترجمة بسيط عند أول Sync أرسله لي وأصلحه.

## لاحقاً (غير مضمّن)
المرحلة 5 (Shizuku اختياري) والمرحلة 6 (VPN اختياري) حسب المواصفات: بعد إثبات الحاجة بالقياس.

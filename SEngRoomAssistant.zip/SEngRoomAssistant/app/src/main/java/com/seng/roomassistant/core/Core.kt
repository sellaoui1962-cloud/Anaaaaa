package com.seng.roomassistant.core

import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil

data class Summary(
    val n: Int, val attempts: Int,
    val median: Double, val p95: Double, val min: Double, val max: Double,
    val jitter: Double, val lossPct: Double,
)

object Stats {
    fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return Double.NaN
        val idx = ceil(p / 100.0 * sorted.size).toInt() - 1
        return sorted[idx.coerceIn(0, sorted.lastIndex)]
    }

    fun median(sorted: List<Double>): Double {
        if (sorted.isEmpty()) return Double.NaN
        val m = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[m] else (sorted[m - 1] + sorted[m]) / 2.0
    }

    fun jitter(series: List<Double>): Double =
        if (series.size < 2) Double.NaN else series.zipWithNext { a, b -> abs(b - a) }.average()

    fun summarize(samples: List<Double>, attempts: Int = samples.size): Summary {
        val s = samples.sorted()
        val loss = if (attempts <= 0) Double.NaN else (attempts - samples.size) * 100.0 / attempts
        return Summary(
            samples.size, attempts, median(s), percentile(s, 95.0),
            s.firstOrNull() ?: Double.NaN, s.lastOrNull() ?: Double.NaN,
            jitter(samples), loss,
        )
    }

    /** Pool several targets; jitter is computed per target (time order) then averaged. */
    fun summarizeMulti(perTarget: List<List<Double>>, attemptsEach: Int): Summary {
        val js = perTarget.filter { it.size > 1 }.map { jitter(it) }
        return summarize(perTarget.flatten(), attemptsEach * perTarget.size)
            .copy(jitter = if (js.isEmpty()) Double.NaN else js.average())
    }
}

data class WifiSnap(val rssi: Int, val linkMbps: Int, val freqMhz: Int, val channel: Int, val band: String)
data class DnsResult(val server: String, val summary: Summary)

data class Report(
    val timestamp: Long, val label: String, val wifi: WifiSnap?,
    val idle: Summary, val dns: List<DnsResult>,
    val downKBps: Double, val upKBps: Double,
    val loadDown: Summary, val loadUp: Summary,
) {
    val bloatDown get() = loadDown.median - idle.median
    val bloatUp get() = loadUp.median - idle.median

    fun toJson(): JSONObject = JSONObject()
        .put("app", "S/ENG Room Network Assistant")
        .put("device", Build.MODEL)
        .put("android_sdk", Build.VERSION.SDK_INT)
        .put("timestamp", timestamp)
        .put("label", label)
        .put("wifi", wifi?.let {
            JSONObject().put("rssi", it.rssi).put("linkMbps", it.linkMbps)
                .put("freqMhz", it.freqMhz).put("channel", it.channel).put("band", it.band)
        } ?: JSONObject.NULL)
        .put("idle", idle.toJson())
        .put("dns", JSONArray().also { a -> dns.forEach { a.put(JSONObject().put("server", it.server).put("summary", it.summary.toJson())) } })
        .put("downKBps", num(downKBps))
        .put("upKBps", num(upKBps))
        .put("loadDown", loadDown.toJson())
        .put("loadUp", loadUp.toJson())
        .put("bufferbloatDownMs", num(bloatDown))
        .put("bufferbloatUpMs", num(bloatUp))
        .put("note", "Public IP and identifiers are intentionally not stored.")

    companion object {
        fun fromJson(o: JSONObject): Report {
            val w = o.optJSONObject("wifi")
            val d = o.optJSONArray("dns") ?: JSONArray()
            return Report(
                o.getLong("timestamp"), o.optString("label"),
                w?.let { WifiSnap(it.optInt("rssi"), it.optInt("linkMbps"), it.optInt("freqMhz"), it.optInt("channel"), it.optString("band")) },
                summaryFrom(o.getJSONObject("idle")),
                (0 until d.length()).map { DnsResult(d.getJSONObject(it).optString("server"), summaryFrom(d.getJSONObject(it).getJSONObject("summary"))) },
                o.optDouble("downKBps", Double.NaN), o.optDouble("upKBps", Double.NaN),
                summaryFrom(o.getJSONObject("loadDown")), summaryFrom(o.getJSONObject("loadUp")),
            )
        }
    }
}

private fun num(d: Double): Any = if (d.isNaN() || d.isInfinite()) JSONObject.NULL else d

fun Summary.toJson(): JSONObject = JSONObject()
    .put("n", n).put("attempts", attempts).put("median", num(median)).put("p95", num(p95))
    .put("min", num(min)).put("max", num(max)).put("jitter", num(jitter)).put("lossPct", num(lossPct))

fun summaryFrom(o: JSONObject) = Summary(
    o.optInt("n"), o.optInt("attempts"),
    o.optDouble("median", Double.NaN), o.optDouble("p95", Double.NaN),
    o.optDouble("min", Double.NaN), o.optDouble("max", Double.NaN),
    o.optDouble("jitter", Double.NaN), o.optDouble("lossPct", Double.NaN),
)

fun quality(s: Summary?): String {
    if (s == null || s.n == 0) return "—"
    val loss = if (s.lossPct.isNaN()) 0.0 else s.lossPct
    val jit = if (s.jitter.isNaN()) 0.0 else s.jitter
    return when {
        loss > 5 || s.p95 > 400 -> "ضعيفة"
        s.median < 80 && jit < 20 && loss < 1 -> "ممتازة"
        s.median < 150 && jit < 40 && loss < 3 -> "جيدة"
        else -> "متوسطة"
    }
}

fun fmtMs(d: Double) = if (d.isNaN()) "—" else "%.0f ms".format(d)
fun fmtKb(d: Double) = if (d.isNaN()) "—" else "%.1f KB/s".format(d)
fun fmtPct(d: Double) = if (d.isNaN()) "—" else "%.1f%%".format(d)

enum class Verdict { IMPROVED, SAME, WORSE }

object Compare {
    private fun delta(a: Double, b: Double): Double? =
        if (a.isNaN() || b.isNaN() || a <= 0) null else (b - a) / a

    fun verdict(before: Report, after: Report): Verdict {
        var better = 0; var worse = 0
        listOf(
            delta(before.idle.median, after.idle.median),
            delta(before.idle.p95, after.idle.p95),
            delta(before.idle.jitter, after.idle.jitter),
            delta(before.loadDown.median, after.loadDown.median),
            delta(before.loadUp.median, after.loadUp.median),
        ).forEach { d ->
            if (d != null) { if (d < -0.10) better++ else if (d > 0.10) worse++ }
        }
        val lossDiff = after.idle.lossPct - before.idle.lossPct
        if (!lossDiff.isNaN()) { if (lossDiff > 2) worse++ else if (lossDiff < -2) better++ }
        return when {
            better > worse -> Verdict.IMPROVED
            worse > better -> Verdict.WORSE
            else -> Verdict.SAME
        }
    }

    fun rows(a: Report, b: Report): List<Triple<String, String, String>> = listOf(
        Triple("Ping median", fmtMs(a.idle.median), fmtMs(b.idle.median)),
        Triple("Ping p95", fmtMs(a.idle.p95), fmtMs(b.idle.p95)),
        Triple("Jitter", fmtMs(a.idle.jitter), fmtMs(b.idle.jitter)),
        Triple("Loss", fmtPct(a.idle.lossPct), fmtPct(b.idle.lossPct)),
        Triple("Latency تحت التنزيل", fmtMs(a.loadDown.median), fmtMs(b.loadDown.median)),
        Triple("Latency تحت الرفع", fmtMs(a.loadUp.median), fmtMs(b.loadUp.median)),
        Triple("Bufferbloat ↓", fmtMs(a.bloatDown), fmtMs(b.bloatDown)),
        Triple("Bufferbloat ↑", fmtMs(a.bloatUp), fmtMs(b.bloatUp)),
        Triple("DNS (أفضل median)", fmtMs(a.dns.minOfOrNull { it.summary.median } ?: Double.NaN), fmtMs(b.dns.minOfOrNull { it.summary.median } ?: Double.NaN)),
        Triple("تنزيل (تقدير)", fmtKb(a.downKBps), fmtKb(b.downKBps)),
        Triple("رفع (تقدير)", fmtKb(a.upKBps), fmtKb(b.upKBps)),
    )
}

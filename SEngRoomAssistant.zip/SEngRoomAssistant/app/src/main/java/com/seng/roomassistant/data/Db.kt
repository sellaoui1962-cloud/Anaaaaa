package com.seng.roomassistant.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val label: String,
    val json: String,
)

@Dao
interface ReportDao {
    @Insert suspend fun insert(e: ReportEntity): Long
    @Query("SELECT * FROM reports ORDER BY timestamp DESC") fun observeAll(): Flow<List<ReportEntity>>
    @Delete suspend fun delete(e: ReportEntity)
}

@Database(entities = [ReportEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ReportDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "seng.db").build().also { inst = it }
        }
    }
}

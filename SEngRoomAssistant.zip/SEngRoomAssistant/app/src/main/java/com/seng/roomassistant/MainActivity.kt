package com.seng.roomassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.seng.roomassistant.ui.MainViewModel
import com.seng.roomassistant.ui.SEngApp
import com.seng.roomassistant.ui.SEngTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SEngTheme { SEngApp(vm) } }
    }
}

package com.seng.roomassistant.ui

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.seng.roomassistant.core.DiagnosticsEngine
import com.seng.roomassistant.core.Probes
import com.seng.roomassistant.core.Report
import com.seng.roomassistant.core.Stats
import com.seng.roomassistant.core.Summary
import com.seng.roomassistant.core.WifiInspector
import com.seng.roomassistant.core.WifiSnap
import com.seng.roomassistant.data.AppDb
import com.seng.roomassistant.data.ReportEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

class ManualState {
    var mark by mutableStateOf<Long?>(null)
    val results = mutableStateListOf<Double>()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val prefs = app.getSharedPreferences("seng", 0)
    private val engine = DiagnosticsEngine(app)

    val reports = dao.observeAll()
        .map { list -> list.mapNotNull { e -> runCatching { e to Report.fromJson(JSONObject(e.json)) }.getOrNull() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var live by mutableStateOf<Summary?>(null)
    var wifi by mutableStateOf<WifiSnap?>(WifiInspector.snapshot(app))
    var sessionOn by mutableStateOf(false)
    var sessionSec by mutableStateOf(0L)
    var progress by mutableStateOf<String?>(null)
    var testLabel by mutableStateOf("اختبار")
    var yallaPkg by mutableStateOf(prefs.getString("yalla", null))
    val selected = mutableStateListOf<Long>()

    val voice = ManualState()
    val chatSend = ManualState()
    val chatRecv = ManualState()

    private var sessionJob: Job? = null

    /** START/STOP: light monitoring only (one small TCP connect every 2 s). No speed tests. */
    fun toggleSession() {
        if (sessionOn) { sessionJob?.cancel(); sessionOn = false; return }
        sessionOn = true
        sessionSec = 0
        val start = SystemClock.elapsedRealtime()
        val window = ArrayDeque<Double?>()
        sessionJob = viewModelScope.launch {
            while (isActive) {
                window.addLast(Probes.tcpRtt("1.1.1.1"))
                if (window.size > 40) window.removeFirst()
                val ok = window.filterNotNull()
                live = Stats.summarize(ok, window.size).copy(jitter = Stats.jitter(ok))
                wifi = WifiInspector.snapshot(getApplication())
                sessionSec = (SystemClock.elapsedRealtime() - start) / 1000
                delay(2000)
            }
        }
    }

    fun runTest() {
        if (progress != null) return
        val label = testLabel.ifBlank { "اختبار" }
        viewModelScope.launch {
            try {
                val r = engine.run(label) { progress = it }
                dao.insert(ReportEntity(timestamp = r.timestamp, label = r.label, json = r.toJson().toString()))
                wifi = r.wifi
                progress = null
            } catch (e: Exception) {
                progress = null
            }
        }
    }

    fun delete(e: ReportEntity) = viewModelScope.launch { dao.delete(e); selected.remove(e.id) }

    fun toggleSelect(id: Long) {
        if (selected.contains(id)) selected.remove(id)
        else { if (selected.size == 2) selected.removeAt(0); selected.add(id) }
    }

    fun setYalla(pkg: String) { yallaPkg = pkg; prefs.edit().putString("yalla", pkg).apply() }
}

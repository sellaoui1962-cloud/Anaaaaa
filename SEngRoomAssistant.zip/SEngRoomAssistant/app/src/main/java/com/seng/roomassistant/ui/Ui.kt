package com.seng.roomassistant.ui

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.seng.roomassistant.core.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SEngTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF00C2A8)) else lightColorScheme(primary = Color(0xFF00897B))
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun SEngApp(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf("الرئيسية" to "🏠", "Room Voice" to "🎙", "Chat" to "💬", "Diagnostics" to "📊")
    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (t, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(ic) }, label = { Text(t, maxLines = 1, fontSize = 11.sp) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> HomeScreen(vm); 1 -> VoiceScreen(vm); 2 -> ChatScreen(vm); else -> DiagScreen(vm) }
        }
    }
}

@Composable
fun RowScope.Metric(title: String, value: String) {
    Card(Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 12.sp)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val s = vm.live
    val last = vm.reports.collectAsState().value.firstOrNull()?.second
    val w = vm.wifi
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("S/ENG", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Button(
            onClick = { vm.toggleSession() }, shape = CircleShape, modifier = Modifier.size(150.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (vm.sessionOn) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary),
        ) { Text(if (vm.sessionOn) "STOP" else "START", fontSize = 26.sp) }
        Text(
            if (vm.sessionOn) "Monitoring — %02d:%02d".format(vm.sessionSec / 60, vm.sessionSec % 60) else "متوقف",
            fontWeight = FontWeight.Medium,
        )
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("جودة الشبكة: ${quality(s)}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("لا توجد عبارة «تم التسريع» — هذا تطبيق قياس. التحسن يظهر فقط في مقارنة قبل/بعد.", fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("Ping", fmtMs(s?.median ?: Double.NaN))
            Metric("Jitter", fmtMs(s?.jitter ?: Double.NaN))
            Metric("Loss", fmtPct(s?.lossPct ?: Double.NaN))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("Upload*", fmtKb(last?.upKBps ?: Double.NaN))
            Metric("Download*", fmtKb(last?.downKBps ?: Double.NaN))
            Metric("p95", fmtMs(s?.p95 ?: Double.NaN))
        }
        Text("* من آخر اختبار Test Now (تقدير). Ping/Jitter/Loss من آخر 40 عينة TCP أثناء الجلسة.", fontSize = 11.sp)
        w?.let { Text("Wi‑Fi: ${it.rssi} dBm • ${it.linkMbps} Mbps • ${it.band} • قناة ${it.channel}", fontSize = 13.sp) }
        Button(onClick = { vm.runTest() }, enabled = vm.progress == null) { Text("Test Now") }
        vm.progress?.let { Text(it, fontSize = 13.sp) }
    }
}

fun todFmt() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

@Composable
fun ResultList(values: List<Double>, unit: String = "ms") {
    if (values.isEmpty()) return
    val sorted = values.sorted()
    Text("عدد القياسات: ${values.size} • median ${"%.0f".format(Stats.median(sorted))} $unit • p95 ${"%.0f".format(Stats.percentile(sorted, 95.0))} $unit", fontWeight = FontWeight.Medium)
    Text("آخر القيم: " + values.takeLast(8).joinToString(" ، ") { "%.0f".format(it) }, fontSize = 12.sp)
}

@Composable
fun CrossDevice(st: ManualState, btn: String, hint: String) {
    var other by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Button(onClick = { st.mark = System.currentTimeMillis() }) { Text(btn) }
    st.mark?.let { Text("لحظتك المسجلة: ${todFmt().format(Date(it))}") }
    OutlinedTextField(other, { other = it }, label = { Text(hint) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Button(enabled = st.mark != null && other.isNotBlank(), onClick = {
        try {
            val f = todFmt()
            val a = f.parse(f.format(Date(st.mark!!)))!!.time
            val b = f.parse(other.trim())!!.time
            st.results.add((a - b).toDouble()); err = null; st.mark = null
        } catch (e: Exception) { err = "صيغة الوقت غير صحيحة (HH:mm:ss.SSS)" }
    }) { Text("احسب الفرق") }
    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    ResultList(st.results)
}

@Composable
fun VoiceScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Room Voice", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("هذا تقدير يدوي وليس قياساً دقيقاً للصوت. التطبيق لا يسجل الميكروفون ولا الصوت. اتفق مع شخص آخر (بموافقته) على كلمة/إشارة: هو يسجل وقت نطقها على جهازه، وأنت تضغط الزر لحظة سماعها، ثم تدخل وقته هنا. يتطلب أن يكون الوقت على الجهازين مضبوطاً تلقائياً (هامش خطأ عشرات ms) وأي قيمة سالبة تعني اختلاف الساعات.", fontSize = 13.sp)
        CrossDevice(vm.voice, "سمعت الإشارة الآن", "وقت نطق الإشارة على جهاز الآخر (HH:mm:ss.SSS)")
        HorizontalDivider()
        val s = vm.live
        Text("مؤشرات الشبكة الحالية (من جلسة START): Ping ${fmtMs(s?.median ?: Double.NaN)} • Jitter ${fmtMs(s?.jitter ?: Double.NaN)} • Loss ${fmtPct(s?.lossPct ?: Double.NaN)}", fontSize = 13.sp)
        Text("إرسال الصوت: لا نقيسه مباشرة؛ راقب Jitter/Loss أثناء حديثك.", fontSize = 12.sp)
    }
}

@Composable
fun ChatScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Chat", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("إرسال رسالة (يدوي): اضغط الزر 1 مع ضغطك إرسال داخل Yalla، ثم الزر 2 عند ظهور التأكيد. لا نقرأ الشاشة ولا نستخدم Accessibility.", fontSize = 13.sp)
        val st = vm.chatSend
        Button(onClick = { st.mark = SystemClock.elapsedRealtime() }) { Text("1) ضغطت إرسال") }
        Button(enabled = st.mark != null, onClick = { st.results.add((SystemClock.elapsedRealtime() - st.mark!!).toDouble()); st.mark = null }) { Text("2) ظهر تأكيد الإرسال") }
        ResultList(st.results)
        HorizontalDivider()
        Text("استقبال رسالة (جهازان بموافقة المشاركين): أدخل وقت إرسالها على جهاز المرسل.", fontSize = 13.sp)
        CrossDevice(vm.chatRecv, "ظهرت الرسالة عندي الآن", "وقت الإرسال على جهاز المرسل (HH:mm:ss.SSS)")
    }
}

fun share(ctx: Context, text: String) {
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
}

fun launchableApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    @Suppress("DEPRECATION")
    return pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        .distinctBy { it.second }.sortedBy { it.first.lowercase() }
}

fun reportText(r: Report): String {
    val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    return buildString {
        appendLine("[${f.format(Date(r.timestamp))}] ${r.label}")
        appendLine("Ping median ${fmtMs(r.idle.median)} • p95 ${fmtMs(r.idle.p95)} • jitter ${fmtMs(r.idle.jitter)} • loss ${fmtPct(r.idle.lossPct)} (n=${r.idle.n}/${r.idle.attempts})")
        appendLine("تحت التنزيل ${fmtMs(r.loadDown.median)} (+${fmtMs(r.bloatDown)}) • تحت الرفع ${fmtMs(r.loadUp.median)} (+${fmtMs(r.bloatUp)})")
        appendLine("DNS: " + r.dns.joinToString(" | ") { "${it.server} ${fmtMs(it.summary.median)}" })
        append("↓ ${fmtKb(r.downKBps)} • ↑ ${fmtKb(r.upKBps)}")
        r.wifi?.let { append("\nWi‑Fi ${it.rssi} dBm • ${it.linkMbps} Mbps • ${it.band} ch${it.channel}") }
    }
}

@Composable
fun DiagScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val reports = vm.reports.collectAsState().value
    var picker by remember { mutableStateOf(false) }
    val sel = reports.filter { vm.selected.contains(it.first.id) }.sortedBy { it.second.timestamp }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("Diagnostics", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ملف Yalla Ludo", fontWeight = FontWeight.Bold)
                    Text("المختار: ${vm.yallaPkg ?: "لم يُختر"}", fontSize = 13.sp)
                    Text("تنبيه: القياسات تخص اتصال الهاتف كله، ولا يمكن عزل حركة Yalla دون VPN محلي (غير مفعّل في هذه النسخة).", fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { picker = true }) { Text("اختر التطبيق") }
                        vm.yallaPkg?.let { p ->
                            OutlinedButton(onClick = { ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } }) { Text("فتح") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(vm.testLabel, { vm.testLabel = it }, label = { Text("اسم الاختبار (مثال: قبل / بعد تغيير DNS)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.runTest() }, enabled = vm.progress == null) { Text("Test Now") }
            Text(vm.progress ?: "الاختبار يستهلك ≈ 4–5 MB كحد أقصى ولا يعمل إلا عند طلبك. لا تشغله أثناء استخدام الغرفة.", fontSize = 12.sp)
        }
        if (sel.size == 2) item {
            val (a, b) = sel[0].second to sel[1].second
            val v = Compare.verdict(a, b)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Compare: «${a.label}» ← «${b.label}»", fontWeight = FontWeight.Bold)
                    Text(
                        when (v) {
                            Verdict.IMPROVED -> "تحسن في هذه المقارنة (كرّر الاختبار في أوقات مختلفة قبل الاعتماد عليه)"
                            Verdict.SAME -> "No measurable improvement — لا فرق قابل للقياس"
                            Verdict.WORSE -> "تدهور"
                        }, fontWeight = FontWeight.Bold,
                    )
                    Compare.rows(a, b).forEach { (k, x, y) ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(k, Modifier.weight(1.4f), fontSize = 12.sp); Text(x, Modifier.weight(1f), fontSize = 12.sp); Text(y, Modifier.weight(1f), fontSize = 12.sp)
                        }
                    }
                    OutlinedButton(onClick = { share(ctx, "[" + sel.joinToString(",") { it.second.toJson().toString() } + "]") }) { Text("تصدير JSON") }
                }
            }
        } else item { Text("اختر تقريرين (✓) للمقارنة. التقارير تُحفظ محلياً بلا IP أو SSID.", fontSize = 12.sp) }

        items(reports, key = { it.first.id }) { (e, r) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = vm.selected.contains(e.id), onCheckedChange = { vm.toggleSelect(e.id) })
                        Text(reportText(r), fontSize = 12.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { share(ctx, reportText(r) + "\n\n" + r.toJson().toString(2)) }) { Text("تصدير") }
                        TextButton(onClick = { vm.delete(e) }) { Text("حذف") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ما الذي يمكن تحسينه؟", fontWeight = FontWeight.Bold)
                    Text("• الهاتف: القرب من الراوتر، تجربة 2.4/5GHz، تقليل التداخل، إغلاق التنزيلات الخلفية.", fontSize = 12.sp)
                    Text("• DNS: يحسّن بدء الاتصال فقط، لا يسرّع صوتاً قائماً.", fontSize = 12.sp)
                    Text("• Bufferbloat (ارتفاع Latency تحت التحميل): الحل في الراوتر (SQM: CAKE/fq_codel) أو عند المزود، وليس من التطبيق.", fontSize = 12.sp)
                    Text("• الازدحام عند مزود 4G وخوادم Yalla خارج سيطرة الهاتف.", fontSize = 12.sp)
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }

    if (picker) {
        val apps = remember { launchableApps(ctx) }
        AlertDialog(
            onDismissRequest = { picker = false },
            confirmButton = {}, dismissButton = { TextButton(onClick = { picker = false }) { Text("إغلاق") } },
            title = { Text("اختر تطبيق Yalla Ludo") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(apps, key = { it.second }) { (label, pkg) ->
                        Column(Modifier.fillMaxWidth().clickable { vm.setYalla(pkg); picker = false }.padding(vertical = 8.dp)) {
                            Text(label, fontWeight = FontWeight.Medium); Text(pkg, fontSize = 11.sp)
                        }
                    }
                }
            },
        )
    }
}

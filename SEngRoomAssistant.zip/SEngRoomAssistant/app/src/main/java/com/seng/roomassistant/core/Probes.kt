package com.seng.roomassistant.core

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import kotlin.random.Random

/** All probes are real measurements. ICMP is not available to apps, so RTT = TCP connect time. */
object Probes {
    val rttTargets = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9")
    val dnsServers = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9")
    val dnsNames = listOf("file.yalla.games", "cloudflare.com")

    suspend fun tcpRtt(host: String, port: Int = 443, timeoutMs: Int = 2500): Double? =
        withContext(Dispatchers.IO) {
            try {
                Socket().use { s ->
                    val t = System.nanoTime()
                    s.connect(InetSocketAddress(host, port), timeoutMs)
                    (System.nanoTime() - t) / 1e6
                }
            } catch (e: Exception) { null }
        }

    suspend fun rttSeries(targets: List<String>, rounds: Int, gapMs: Long): Summary = coroutineScope {
        val per = targets.map { mutableListOf<Double>() }
        repeat(rounds) {
            targets.mapIndexed { i, t -> async { i to tcpRtt(t) } }.awaitAll()
                .forEach { (i, v) -> if (v != null) per[i].add(v) }
            delay(gapMs)
        }
        Stats.summarizeMulti(per, rounds)
    }

    /** Samples RTT while [load] (blocking, returns KB/s) runs in parallel. */
    suspend fun rttUnderLoad(targets: List<String>, load: () -> Double): Pair<Summary, Double> = coroutineScope {
        val job = async(Dispatchers.IO) { load() }
        val per = targets.map { mutableListOf<Double>() }
        var rounds = 0
        while (job.isActive) {
            targets.mapIndexed { i, t -> async { i to tcpRtt(t) } }.awaitAll()
                .forEach { (i, v) -> if (v != null) per[i].add(v) }
            rounds++
            delay(150)
        }
        Stats.summarizeMulti(per, rounds) to job.await()
    }

    /** Direct UDP DNS query (bypasses the system cache of the resolver choice). Returns ms. */
    suspend fun dnsQuery(server: String, name: String, timeoutMs: Int = 2000): Double? =
        withContext(Dispatchers.IO) {
            try {
                DatagramSocket().use { s ->
                    s.soTimeout = timeoutMs
                    val id = Random.nextInt(0xFFFF)
                    val bo = ByteArrayOutputStream()
                    val d = DataOutputStream(bo)
                    d.writeShort(id); d.writeShort(0x0100)
                    d.writeShort(1); d.writeShort(0); d.writeShort(0); d.writeShort(0)
                    name.split(".").forEach { d.writeByte(it.length); d.write(it.toByteArray()) }
                    d.writeByte(0); d.writeShort(1); d.writeShort(1)
                    val q = bo.toByteArray()
                    val addr = InetAddress.getByName(server)
                    val t = System.nanoTime()
                    s.send(DatagramPacket(q, q.size, addr, 53))
                    val buf = ByteArray(512)
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val ms = (System.nanoTime() - t) / 1e6
                    val rid = ((buf[0].toInt() and 0xFF) shl 8) or (buf[1].toInt() and 0xFF)
                    if (rid == id) ms else null
                }
            } catch (e: Exception) { null }
        }

    suspend fun dnsSummary(server: String, attemptsPerName: Int = 3): DnsResult {
        val ok = mutableListOf<Double>()
        var attempts = 0
        for (name in dnsNames) repeat(attemptsPerName) {
            attempts++
            dnsQuery(server, name)?.let { ok.add(it) }
            delay(100)
        }
        return DnsResult(server, Stats.summarize(ok, attempts))
    }

    /** Blocking. Time-boxed and byte-capped. Returns KB/s or NaN. */
    fun download(durationMs: Long, maxBytes: Long): Double = try {
        val c = URL("https://speed.cloudflare.com/__down?bytes=$maxBytes").openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000
        val ins = c.inputStream
        val start = System.nanoTime()
        var total = 0L
        val buf = ByteArray(16 * 1024)
        ins.use {
            while ((System.nanoTime() - start) / 1_000_000 < durationMs) {
                val r = it.read(buf)
                if (r < 0) break
                total += r
            }
        }
        c.disconnect()
        total / 1024.0 / ((System.nanoTime() - start) / 1e9)
    } catch (e: Exception) { Double.NaN }

    /** Blocking. Rate is bytes handed to the socket per second: an estimate, may read high on tiny windows. */
    fun upload(durationMs: Long, maxBytes: Long): Double = try {
        val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 6000
        c.requestMethod = "POST"; c.doOutput = true
        c.setChunkedStreamingMode(16 * 1024)
        val chunk = ByteArray(16 * 1024)
        val start = System.nanoTime()
        var total = 0L
        c.outputStream.use { out ->
            while ((System.nanoTime() - start) / 1_000_000 < durationMs && total < maxBytes) {
                out.write(chunk); total += chunk.size
            }
            out.flush()
        }
        val secs = (System.nanoTime() - start) / 1e9
        runCatching { c.responseCode }
        c.disconnect()
        total / 1024.0 / secs
    } catch (e: Exception) { Double.NaN }
}

object WifiInspector {
    @Suppress("DEPRECATION")
    fun snapshot(ctx: Context): WifiSnap? = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val i = wm.connectionInfo
        if (i == null || i.rssi <= -127) null else {
            val f = i.frequency
            val ch = when {
                f == 2484 -> 14
                f in 2400..2483 -> (f - 2407) / 5
                f in 5000..5900 -> (f - 5000) / 5
                else -> 0
            }
            val band = when { f < 3000 -> "2.4GHz"; f < 5925 -> "5GHz"; else -> "6GHz" }
            WifiSnap(i.rssi, i.linkSpeed, f, ch, band)
        }
    } catch (e: Exception) { null }
}

class DiagnosticsEngine(private val ctx: Context) {
    suspend fun run(label: String, onProgress: (String) -> Unit): Report {
        val t = Probes.rttTargets
        onProgress("1/4 قياس RTT في حالة الخمول…")
        val idle = Probes.rttSeries(t, 20, 150)
        onProgress("2/4 قياس DNS…")
        val dns = Probes.dnsServers.map { Probes.dnsSummary(it) }
        onProgress("3/4 تنزيل مع قياس latency…")
        val (ld, down) = Probes.rttUnderLoad(t) { Probes.download(4000, 3_000_000) }
        onProgress("4/4 رفع مع قياس latency…")
        val (lu, up) = Probes.rttUnderLoad(t) { Probes.upload(4000, 1_500_000) }
        return Report(System.currentTimeMillis(), label, WifiInspector.snapshot(ctx), idle, dns, down, up, ld, lu)
    }
}

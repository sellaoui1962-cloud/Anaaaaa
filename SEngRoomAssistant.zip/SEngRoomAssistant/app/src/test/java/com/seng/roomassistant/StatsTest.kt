package com.seng.roomassistant

import com.seng.roomassistant.core.Stats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StatsTest {
    @Test fun medianAndP95() {
        val s = Stats.summarize(listOf(10.0, 20.0, 30.0, 40.0, 100.0), 5)
        assertEquals(30.0, s.median, 0.001)
        assertEquals(100.0, s.p95, 0.001)
        assertEquals(0.0, s.lossPct, 0.001)
    }

    @Test fun jitterIsMeanAbsDiff() {
        assertEquals(55.0 / 3, Stats.jitter(listOf(10.0, 20.0, 50.0, 35.0)), 0.001)
    }

    @Test fun lossCounted() {
        val s = Stats.summarize(listOf(10.0, 12.0), 4)
        assertEquals(50.0, s.lossPct, 0.001)
    }

    @Test fun emptyIsNaN() {
        assertTrue(Stats.summarize(emptyList(), 0).median.isNaN())
    }
}
